#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

bool checkFname(char * firstName){
    
    for(unsigned int i=0;i<(unsigned )strlen(firstName);i++){
      if(int(firstName[i])<65){

      cout<<"\n\t\t\t\tEnter your correct Name!";
      return false;
    }
  }
    cout << "\n\t\t\tFirst name is valid!";
    return true;

  }

  bool checkPhoneno(long phonenumber){

    if(phonenumber>999999999 && phonenumber<10000000000){
      cout << "\n\t\t\tPhone no is valid!";
      return true;
    }
    
    cout<<"\n\t\t\t\tEnter Correct 10 digit Phone Number!";
    return false;

  }

  bool checkage(int age){

    if(age>0 && age<101){
        cout << "\n\t\t\tPhone no is valid!";
      return true;
    }
    
    cout<<"\n\t\t\t\tEnter your correct age!";
    return false;

  }