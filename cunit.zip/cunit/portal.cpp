#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

bool logPortal(int input)
{
      if(input == 1)
        {    
            cout<<"\n\t\t\t\tRedirect to signUp page!";
            return true;
        }

    else if(input == 2)
        {
           cout<<"\n\t\t\t\tRedirect to Login page!";
            return true;
        }
        
   else if(input == 3)
        {   
            cout<<"\n\t\t\t\tRedirect to Forgot password page!";
            return true;
        }
     else if(input == 4)
        {   
            cout<<"\n\t\t\t\tExit the program!";
            return true;
        }    
   
     else
        {   
            cout<<"\n\t\t\tInvalid Input Try Again!";
            return false;
        }       
    
}