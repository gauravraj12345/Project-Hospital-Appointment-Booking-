#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <ctime>
#include <userdata.h>
#include <userlogin.h>
#include <patient.h>
#include <portal.h>
#include <doctor.h>

using namespace std;

int main()
{   

    system("clear");
    welcome_screen();
    logPortal();

    return 0;
}
	
