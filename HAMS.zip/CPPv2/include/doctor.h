#ifndef doctor_h
#define doctor_h

#include <string>

void yourAppoint(int);
void complete(char *,char *,int);
void changeStatus(char *,char *,int);


#endif