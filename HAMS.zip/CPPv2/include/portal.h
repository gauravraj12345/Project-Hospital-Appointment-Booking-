#ifndef portal_h
#define portal_h

#define LIMIT 15

#include <string>
#include <userdata.h>
#include <userlogin.h>
#include <patient.h>
#include <portal.h>
#include <doctor.h>


class personaldata{
protected:
	char firstName[LIMIT];
    char lastName[LIMIT];
    int age;
    long phonenumber;
    char gender;

};

void welcome_screen();
void title();
void logPortal();
void adminPortal(char * ,char *);
void docPortal(char * ,char * ,int);
void timeset();


#endif