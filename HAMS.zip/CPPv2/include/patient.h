#ifndef patient_h
#define patient_h

#include <userdata.h>
#include <userlogin.h>
#include <patient.h>
#include <portal.h>
#include <doctor.h>


void addPatient(char *,char *);
void readPatient(char *,char *);
void searchPatient(char *,char *);
void checkDoc(char *,char *);

#define LIMIT 15

class patient :public personaldata{
	private:

	    char symptoms[LIMIT];
	    int doc;
	    char date[LIMIT];
	    int userid;
	    int slot;
	public:
		int getIdp();
		char * getFName();
    	char * getLName();
		int getIdd();
		int getSlot();
		void appointment();
		int setUserId();
		void setTime();
		void display();
		void readPatient();
		void showPatient();
		void complete();
			
		
};

#endif