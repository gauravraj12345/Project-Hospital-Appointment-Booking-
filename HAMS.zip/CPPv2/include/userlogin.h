#ifndef userlogin_h
#define userlogin_h

#define LIMIT 15

#include <string>
#include <userdata.h>
#include <userlogin.h>
#include <patient.h>
#include <portal.h>
#include <doctor.h>

void signUp();
void readLog();
void forgotPassword();
void complete();
void readCredit();



class userCredit{
private:
	char name[LIMIT];
public:
	bool checkCredit(char *);
    void putCredit(char *);
    void display();
};

class userlogin :public personaldata{
	private:
		int userid;
		char username[LIMIT];
		char pass[LIMIT];
		int access;
	public:
    	void setCredit();
    	int getId();
    	void update();
    	char * getUserName();
    	char * getPass();
    	char * getFName();
    	char * getLName();
    	void display();
    	void setCredit(int ,char *,char *,int);
      	void forgotPassword();
      	void readDoctor();

      	
		
};

#endif