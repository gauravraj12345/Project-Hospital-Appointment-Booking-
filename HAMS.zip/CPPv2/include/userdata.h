#ifndef userdata_h
#define userdata_h

#include <userdata.h>
#include <string>
#include <userlogin.h>
#include <patient.h>
#include <portal.h>
#include <doctor.h>


void readUp();
void login();
void sortPatient(char* , char* );
bool compareFunction (char* , char* );

class userdata: public personaldata{
	private:
		int userid;
		int profile;	
	

	public:
		int getIdn();
		int setUserId(int);
    	void registerUser();
    	void display();
    	char * getFName();
    	char * getLName();
   	
		
};

class admin: public userdata{
	private:
		int userid;
		int profile;	

		
};

class doctor: public userdata{
	private:
		int userid;
		int profile;	

		
};
#endif