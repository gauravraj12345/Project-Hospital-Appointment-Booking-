#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <userdata.h>
#include <userlogin.h>
#include <patient.h>
#include <portal.h>
#include <doctor.h>

using namespace std;

    char pfname[15];
	char plname[15];
	int patientid;
	char scheduletime[15];
	char pgender;
	int page;
	char psymptoms[15];

int patient::getIdp(){
	return userid;		
}

int patient::getIdd(){
	return doc;		
}

int patient::getSlot(){
	return slot;		
}
void patient::complete(){
	slot =0;
	cout << "\n\t\t\tYou have completed the task";
}

char *patient::getFName(){
	return firstName;		
}

char* patient::getLName(){
	return lastName;		
}

void patient::appointment(){
	title();
	cout<<"\n\n\t\t\t\t\tPATIENT APPOINTMENT ";
	cout<<"\n\t\t\t----------------------------------------------------------";
	userid = setUserId();
	slot = 1 ;
	cout<<"\n\n\n\t\t\t\tID : "<< userid;
	patientid = userid;
	cout<<"\n\n\t\t\t\tEnter your first name : ";
	cin>>firstName;
	strcpy(pfname,firstName);
	cout<<"\n\t\t\t\tEnter your last name : ";
	cin>>lastName;
	strcpy(plname,lastName);
	cout<<"\n\t\t\t\tEnter your Gender(m/f) : ";
	cin>>gender;
	pgender = gender;
	cout<<"\n\t\t\t\tEnter your Age : ";
	cin>>age;
	page = age;
	cout<<"\n\t\t\t\tEnter your phone number : ";
	cin>>phonenumber;
	cout<<"\n\t\t\t\tSymptoms: ";
	cin>>symptoms;
	strcpy(psymptoms,symptoms);
	cout<<"\n\t\t\t\tEnter the Doctor ID: ";
	cin>>doc;
	
	system("clear");
	
}

void patient::setTime(){
	time_t now = time(0);
	now += 1800;
    char* dt = ctime(&now);
    cout <<  dt ;
    strcpy(scheduletime,dt);

    
}

int patient:: setUserId(){
	userid=1100721;
 	int count=0;
 	userdata user;
    fstream fptr1;
	fptr1.open("data/bin2.dat", ios::in);
	if(!fptr1){
		return userid;
	}

	while(fptr1.read((char *)&user,sizeof(user))){
		count++	;
	}
	
	fptr1.close();

	return (userid + count);
	
 }

 void patient::display(){
 	title();
 	cout<<"\n\n\t\t\t\t\tAPPOINTMENT STATUS ";
	cout<<"\n\t\t\t----------------------------------------------------------";
	cout<<"\n\n\t\t\t\tId : "<<userid;
	cout<<"\n\t\t\t\tName : "<<firstName<<" "<<lastName;
	cout<<"\n\t\t\t\tGender : "<<gender;
	cout<<"\n\t\t\t\tAge : "<<age;
	cout<<"\n\t\t\t\tPhone Number : "<<phonenumber;
	cout<<"\n\t\t\t\tSymptoms : "<<symptoms;
	cout<<"\n\t\t\t\tDoctor ID: "<<doc;
	cout<<"\n\n\t\t\t\tAppointment Time : ";
	setTime();
	cout<<"\n\n\nYour Appointment has successfully created....";   
	cout<<"\n\nPress enter key to continue....";                              
    getchar();
    getchar();
}

void patient::readPatient()
{    
	 
	 cout <<"\n\n\t\t\t " << userid<<"\t";
	 cout << firstName<<" "<< lastName<<"\t  ";
	 if(slot)
	 {
	 	cout << "Appointment Pending";
	 }
	 else{
	 	cout << "Appointment Completed";
	 }
}



void patient::showPatient()
{    
	 
	 cout <<"\n\n\t\t\t" << "User ID"<<"    | Name \t\t | Gender | Age  | Phone Number     | Symptoms   | Doctor";
	 cout <<"\n\n\t\t\t------------------------------------------------------------------------------------------------------";
	 cout <<"\n\n\t\t\t" << userid<<"   \t" <<firstName<<" "<<lastName<<"\t   "<<gender<<"     "<<age<<"     ";
	 cout <<phonenumber<<" \t"<<symptoms<<"     "<<doc<<endl;
}

void addPatient(char *fname,char *lname){
	
	patient userP;
	userP.appointment();
	userP.display();
	fstream fptr;
	fptr.open("data/bin2.dat", ios::app);
	if(!fptr){
		cerr<<"Error in registration"<<endl;
		return;
	}
	fptr.write((char *)&userP, sizeof(userP));
	fptr.close();

	ofstream file;
	file.open("data/info.dat", ios::app);
	file<<pfname<<' '<<plname<<"       "<<patientid<<"      "<<scheduletime;
	
	
	file.close();


	system("clear");
	adminPortal(fname,lname);
	
}

void readPatient(char *fname,char *lname)
{  
	title();
	cout<<"\n\n\t\t\t\t\tAPPOINTMENT STATUS";
	cout<<"\n\t\t\t----------------------------------------------------------";
    patient userP;
    fstream fptr;
	fptr.open("data/bin2.dat", ios::in);
	if(!fptr){
		cerr<<"Error in registration"<<endl;
		return;
	}
    
    cout <<"\n\n\t\t\t ID\t\t| Name \t\t    |  Status ";
    cout <<"\n\n\t\t\t-------------------------------------------------------------";
	while(fptr.read((char *)&userP,sizeof(userP))){
		userP.readPatient();
	}
	
	fptr.close();
	cout<<"\n\n\n\tPress '1' key to sort by Name....";
	cout<<"\n\tPress '2' key to go back...";                              
    int input;
    cin>>input;
      if(input == 1)
        {    
            system("clear");
            sortPatient(fname,lname);
        }

    else if(input == 2)
        {
            system("clear");
	        adminPortal(fname,lname);
        }
    

	
}

void searchPatient(char *fname,char *lname)
{
	title();
	cout<<"\n\n\t\t\t\t\tSEARCH PATIENT RECORD ";
	cout<<"\n\t\t\t----------------------------------------------------------";
	int id;
	int flag=0;
	patient userP;
	cout<<"\n\t\t\tEnter the ID you want to search: ";
	cin>>id;
	fstream fptr;
	fptr.open("data/bin2.dat", ios::in);
	if(!fptr){
		cerr<<"Error in registration"<<endl;
		return;
	}

	while(fptr.read((char *)&userP,sizeof(userP))){
		if(id == userP.getIdp()){
		userP.showPatient();
		flag = 1;
	     }
	}

	if(!flag){
		cout<<"there is no such records"<<endl;
	}
	
	fptr.close();

	cout<<"\n\n\n\tPress enter key to continue....";                              
    getchar();
    getchar();
    system("clear");
	adminPortal(fname,lname);

}


void checkDoc(char *fname,char *lname)
{
	title();
	cout<<"\n\n\t\t\t\t\tCHECK DOCTOR AVAILABLITY ";
	cout<<"\n\t\t\t----------------------------------------------------------";
	userlogin user;
    fstream fptr;
	fptr.open("data/bin1.dat", ios::in);
	if(!fptr){
		cerr<<"Error in registration"<<endl;
		return;
	}
    
    cout <<"\n\n\t\t\t ID    | \t Name  | \t\t  Status ";
    cout <<"\n\n\t\t\t---------------------------------------------------------------------------";

	while(fptr.read((char *)&user,sizeof(user))){
		int uId = user.getId();
		if(uId <1000 ){
			user.readDoctor();
			
		}

	
    }
    fptr.close();

    cout<<"\n\n\n\tPress enter key to continue....";                              
    getchar();
    getchar();
    system("clear");
	adminPortal(fname,lname);
}