#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <vector>
#include <userdata.h>
#include <userlogin.h>
#include <patient.h>
#include <portal.h>
#include <doctor.h>

using namespace std;


int userlogin::getId(){
	return userid;		
}

void userlogin::update(){
	if (access)
	{
		access =0;
		cout<<"\n\t\t\tYour Profile is updated to Unavailabe"; 
	}
	else{
		access =1;
		cout<<"\n\t\t\tYour Profile is updated to Availabe"; 
	}	
}



char* userlogin::getUserName(){
	return username;		
}

char* userlogin::getPass(){
	return pass;		
}

char* userlogin::getFName(){
	return firstName;		
}

char* userlogin::getLName(){
	return lastName;		
}

void userlogin::readDoctor()
{    
	 
	 cout <<"\n\n\t\t\t   " << userid<<"\t\t" << firstName<<" "<<lastName<<"\t\t";
	 if(access)
	 {
	 	cout << "Available";
	 }
	 if(!access){
	 	cout << "Unavailabe";
	 }
}

void userlogin::setCredit(int uid ,char * fname,char *lname,int rep)
{  

    userCredit cred; 
	char uname[15];
	userid = uid;
	access = rep;
	strcpy(firstName,fname) ;
	strcpy(lastName,lname) ;
	cout<<"\n\t\t\tEnter Username : ";
	do
	{
		cin >> uname;
	}
	while(cred.checkCredit(uname));
	cred.putCredit(uname);
	strcpy(username,uname);
	cout<<"\n\t\t\tEnter Password : ";
	cin>>pass;
	cout<<"\n\nYour Profile has successfully created....";   
	cout<<"\n\nPress enter key to continue....";                              
    getchar();
    getchar();
}

bool userCredit::checkCredit(char * uname)
{   
    fstream fptr;
	fptr.open("data/bin3.dat", ios::in);
	if(!fptr){
		cerr<<"Error in registration"<<endl;
		exit(0);
	}

	while(fptr.read((char *)&name,sizeof(name))){
		if(strcmp(name,uname)==0){
			cout << "\n\t\t\tAlready exist try again!";
			return true;
	      }	
	   }	
    fptr.close();
    return false;

}

void userCredit::putCredit(char * uname)
{   
	strcpy(name,uname);
    fstream fptr1;
	fptr1.open("data/bin3.dat", ios::app);
	try
	{
		if(!fptr1){
		throw"Error in registration";
		
	}
}
	catch(const char *estr)
	{
		cout<<estr<<endl;
	}
    fptr1.write((char *)&name, sizeof(name));
    fptr1.close();
    
}

void userlogin::display(){
	cout<<"\nId : "<<userid;
	cout<<"\nName : "<<firstName;
	cout<<"\nUser Name : "<<username;
	cout<<"\nPassword : "<<pass;
	
}

void userCredit::display(){
	cout<<name<< " " ;
	
}

void userlogin::forgotPassword(){
	cout<<"\n\t\t\tchecking the data"<<endl;
	cout<<"\n\t\t\tenter new password"<<endl;
	cin>>pass;
}



void readLog(){
    userlogin user;
    fstream fptr;
	fptr.open("data/bin1.dat", ios::in);
	try
	{
		if(!fptr){
		throw"Error in registration";
		
	}
}
	catch(const char *estr)
	{
		cout<<estr<<endl;
	}

	while(fptr.read((char *)&user,sizeof(user))){
		user.display();
	}
	
	fptr.close();
	
}

void readCredit(){
    userCredit cred;
    fstream fptr;
	fptr.open("data/bin3.dat", ios::in);
	try
	{
		if(!fptr){
		throw"Error in registration";
		
	}
}
	catch(const char *estr)
	{
		cout<<estr<<endl;
	}

	while(fptr.read((char *)&cred,sizeof(cred))){
		cred.display();

	}
	
	fptr.close();
	
}


void signUp(){
	title();
	cout<<"\n\n\t\t\t\t\tREGISTER YOUR ACCOUNT  ";
	cout<<"\n\t\t\t----------------------------------------------------------"<<endl;
	userdata userU;
	userU.registerUser();
	userU.display();
	fstream fptr;
	fptr.open("data/bin.dat", ios::app);
	try
	{
		if(!fptr){
		throw"Error in registration";
		
	}
}
	catch(const char *estr)
	{
		cout<<estr<<endl;
	}
	fptr.write((char *)&userU, sizeof(userU));
	fptr.close();
	
	int rep=1;
	userlogin userL;
	userL.setCredit(userU.getIdn(),userU.getFName(),userU.getLName(),rep);
	fstream fptr1;
	fptr1.open("data/bin1.dat", ios::app);
	if(!fptr1){
		cerr<<"Error in registration"<<endl;
		return;
	}
	fptr1.write((char *)&userL, sizeof(userL));
	fptr1.close();
	system("clear");
	logPortal();
}

void forgotPassword(){
	title();
    char  uname[15];
    cout<<"\n\n\t\t\tEnter username : ";
    cin>>uname;
    userlogin userL;
    fstream fptr;
    fptr.open("data/bin1.dat", ios::in|ios::out);
    try
	{
		if(!fptr){
		throw"Error in registration";
		
	}
}
	catch(const char *estr)
	{
		cout<<estr<<endl;
	}
    while(fptr.read((char *)&userL, sizeof(userL))){
        if(!strcmp(userL.getUserName(),uname)){
            userL.forgotPassword();
            fptr.seekg(-sizeof(userL),ios::cur);
            fptr.write((char *)&userL,sizeof(userL));
        }

    }
    fptr.close();
    system("clear");
	logPortal();
}