#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <ctime>
#include <algorithm>
#include <vector>
#include <userdata.h>
#include <userlogin.h>
#include <patient.h>
#include <portal.h>
#include <doctor.h>

using namespace std;




int userdata::getIdn(){
	return userid;		
}

char* userdata::getFName(){
	return firstName;		
}

char* userdata::getLName(){
	return lastName;		
}

void userdata::registerUser(){
	cout<<"\n\n\t\t\t\tEnter your first name : ";
	cin>>firstName;
	cout<<"\n\t\t\t\tEnter your last name : ";
	cin>>lastName;
	cout<<"\n\t\t\t\tEnter your Gender(m/f) : ";
	cin>>gender;
	cout<<"\n\t\t\t\tEnter your Age : ";
	cin>>age;
	cout<<"\n\t\t\t\tEnter your phone number : ";
	cin>>phonenumber;
	system("clear");
	title();
	cout<<"\n\n\t\t\t\t\tSELECT YOUR USER PROFILE  ";
	cout<<"\n\t\t\t----------------------------------------------------------"<<endl;
	cout<<"\n\n\t\t\t\tOpen for Doctor Profile- Press '1': ";
	cout<<"\n\n\t\t\t\tOpen for Receptionist Profile- Press '2': ";
	cin>>profile;

	userid = setUserId(profile);
}



 int userdata:: setUserId(int profile){
 	userid=1000;
 	int count=1;
 	userdata user;
   fstream fptr1;
   if(profile == 1){
   	userid/= 10;
   } 

	fptr1.open("data/bin.dat", ios::in);
	try
	{
		if(!fptr1){
		throw"Error in registration";
		
	}
}
	catch(const char *estr)
	{
		cout<<estr<<endl;
	}

	while(fptr1.read((char *)&user,sizeof(user))){
		count++	;
	}
	
	fptr1.close();

	return (userid + count);
	
 }

void userdata::display(){
	system("clear");
	title();
	cout<<"\n\n\t\t\t\t\tENTER USER ID AND PASSWORD ";
	cout<<"\n\t\t\t----------------------------------------------------------";
	cout<<"\n\n\t\t\tId : "<<userid;
	cout<<"\n\t\t\tName : "<<firstName<<" "<<lastName;
	cout<<"\n\t\t\tGender : "<<gender;
	cout<<"\n\t\t\tAge : "<<age;
	cout<<"\n\t\t\tPhone Number : "<<phonenumber<<endl;
	cout<<"\n\t\t\t----------------------------------------------------------"<<endl;
}




void readUp(){
    userdata user;
    fstream fptr;
	fptr.open("data/bin.dat", ios::in);
	try
	{
		if(!fptr){
		throw"Error in registration";
		
	}
}
	catch(const char *estr)
	{
		cout<<estr<<endl;
	}

	while(fptr.read((char *)&user,sizeof(user))){
		user.display();
	}
	
	fptr.close();
	
}



void login(){
	title();
	cout<<"\n\n\t\t\t\t\tENTER YOUR USER ID AND PASSWORD ";
	cout<<"\n\t\t\t----------------------------------------------------------";
	int flag =0;
	char uname[15], password[15],fname[15],lname[15];
	int uId;
	jump :
	    cout<<"\n\n\t\t\t\tEnter username : ";
	    cin>>uname;
			cout<<"\n\t\t\t\tEnter password : ";
			cin>>password;
	userlogin user;
  fstream fptr;
	fptr.open("data/bin1.dat", ios::in);
	try
	{
		if(!fptr){
		throw"Error in registration";
		
	}
}
	catch(const char *estr)
	{
		cout<<estr<<endl;
	}

	while(fptr.read((char *)&user,sizeof(user))){
		if(!strcmp(user.getUserName(),uname)){
			uId = user.getId();
			strcpy(fname,user.getFName());
			strcpy(lname,user.getLName());

			if(uId > 1000){
				if(!strcmp(user.getPass(),password)){
					system("clear");
					adminPortal(fname,lname);
				}
			}
			if(uId < 1000){
				if(!strcmp(user.getPass(),password)){
					system("clear");
					docPortal(fname,lname,uId);
				}	
	      }
		
	   }	
   }

   if(!flag){
   	system("clear");
   	title();
   	cout<<"\n\t\t\t\tEnter Correct Credential! ";
   	goto jump;
   	

   }
}


void sortPatient(char *fname,char *lname)
{  
		title();
		cout<<"\n\n\t\t\t\t\tSORT BY NAME ";
		cout<<"\n\t\t\t----------------------------------------------------------";
		cout<<"\n\n\t\t\tS No. Name\t\t ID No.\t\t Schedule ";
		cout<<"\n\t\t\t----------------------------------------------------------";
		
		fstream fptr;
		fptr.open("data/bin2.dat", ios::in | ios :: binary);
		try
		{
				if(!fptr){
				throw"Error in registration";

		}
		}
				catch(const char *estr)
		{
				cout<<estr<<endl;
		}

		vector <string>  v;

		ifstream file;
		file.open("data/info.dat");
		string line;
		while(getline(file, line)){
				v.push_back(line);
		}
		file.close();
    
    sort(v.begin(), v.end());
		for(long unsigned int i=0;i<v.size();++i){
				cout<<"\n\t\t\t"<<i+1<<".   "<<v[i]<<endl;
		}

    cout<<"\n\nPress enter key to continue....";                              
    getchar();
    getchar();
		system("clear");
		adminPortal(fname,lname);

}