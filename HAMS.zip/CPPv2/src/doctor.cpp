#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <userdata.h>
#include <userlogin.h>
#include <patient.h>
#include <portal.h>
#include <doctor.h>


using namespace std;

void yourAppoint(int id)
{
	cout<<"\n\n\t\t\t\tYOUR SCHEDULE : "<<endl;
	int flag =0;
	patient userP;
	fstream fptr;
	fptr.open("data/bin2.dat", ios::in);
	try
	{
		if(!fptr){
		throw"Error in registration";
		
	}
}
	catch(const char *estr)
	{
		cout<<estr<<endl;
	}
    int slot;
	while(fptr.read((char *)&userP,sizeof(userP))){
		slot =userP.getSlot();
		if(id == userP.getIdd()&& slot ==1){

		userP.showPatient();
		flag = 1;
	     }
	}

	if(!flag){
		cout<<"\n\t\t\t\tYou have no schedule for now"<<endl;
	}
	
	fptr.close();

}

void complete(char * fname,char * lname,int id)
{
	title();
	cout<<"\n\n\t\t\t\t\tCOMPLETE YOUR APPOINTMENT ";
	cout<<"\n\t\t\t----------------------------------------------------------";
    int uid;
	int flag=0;
	patient userP;
	cout<<"\n\t\t\tEnter the ID you want to search: ";
	cin>>uid;
	fstream fptr;
	fptr.open("data/bin2.dat", ios::in|ios::out);
	try
	{
		if(!fptr){
		throw"Error in registration";
		
	}
}
	catch(const char *estr)
	{
		cout<<estr<<endl;
	}
    
	while(fptr.read((char *)&userP,sizeof(userP))){
		if(uid == userP.getIdp()){
			userP.complete();
			fptr.seekg(-sizeof(userP),ios::cur);
	        fptr.write((char *)&userP,sizeof(userP));
			flag = 1;
	     }
	}

	if(!flag){
		cout<<"there is no such records"<<endl;
	}
	
	fptr.close();

	cout<<"\n\n\n\tPress enter key to continue....";                              
    getchar();
    getchar();
    system("clear");
	docPortal(fname,lname,id);

}

void changeStatus(char * fname,char * lname,int id)
{  
	title();
	cout<<"\n\n\t\t\t\t\tCHANGE YOUR AVAILABILITY ";
	cout<<"\n\t\t\t----------------------------------------------------------";
	int flag=0;
	userlogin userL;
	fstream fptr;
	fptr.open("data/bin1.dat", ios::in|ios::out);
	try
	{
		if(!fptr){
		throw"Error in registration";
		
	}
}
	catch(const char *estr)
	{
		cout<<estr<<endl;
	}
    
	while(fptr.read((char *)&userL,sizeof(userL))){
		if(id == userL.getId()){
			userL.update();
			fptr.seekg(-sizeof(userL),ios::cur);
	        fptr.write((char *)&userL,sizeof(userL));
			flag = 1;

	     }
	}

	if(!flag){
		cout<<"there is no such records"<<endl;
	}
	
	fptr.close();

	cout<<"\n\n\n\tPress enter key to continue....";                              
    getchar();
    getchar();
    system("clear");
	docPortal(fname,lname,id);

}
